<!DOCTYPE html>
<html lang="en">
<head>
<link rel="stylesheet" href="style.css">
    <title>toets</title>
    
    <form action="" method="post">
   
    <div id="inlog"> 
    <h1> Newsletter sign up</h1>
    <label for="username">Gebruikersnaam:</label><br>
    <input type="text" id="username" name="username" placeholder="gebruikersnaam"> <br>
    <label for="pwd">Wachtwoord:</label><br>
    <input type="password" id="pwd" name="password" placeholder="wachtwoord"> <br>
    <button type="submit">Login</button>

    <?php
                    if(isset($_POST["username"]) && isset($_POST["password"]))
                    {
                    
                    
                        $gebruikersnaam = $_POST["username"];
                        $wachtwoord = $_POST["password"];
                        
                        $gebruikerinfo = 
                            array (
                                array("gebruikersnaam"  => "noah", "ww" => "Noah123"),
                                
                            );
                               
                        
                        
                        foreach ($gebruikerinfo as $aGebruiker) 
                        {
                           if($aGebruiker['gebruikersnaam'] == $gebruikersnaam && $aGebruiker['ww'] == $wachtwoord)
                           {
                                echo "Dankjewel $gebruikersnaam voor je aanmelding";
                           }
                    
                           elseif($aGebruiker['gebruikersnaam'] != $gebruikersnaam || $aGebruiker['ww'] != $wachtwoord)
                           {
                                echo "de gebruikersnaam of wachtwoord is onjuist";
                           }
                        }
                    }
                ?>

</div>

</form>
</head>
<body>
<div id="container">
        <div id="header">christmas greetings</div>
        <div id="nav" class="rounded">
            <a href="">home</a>
            <a href="">menu a</a>
            <a href="">menu b</a>
            <a href="">menu c</a>
        </div>
            <div id="main">
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi feugiat tellus ac mi ornare rhoncus. Sed tempor, ante eleifend fringilla eleifend, orci sem suscipit tellus, ullamcorper consectetur justo nunc sit amet turpis. Etiam felis eros, ultricies quis felis ac, malesuada blandit purus. Integer sed tellus eget ligula malesuada dignissim ac malesuada lacus. Quisque pharetra pellentesque massa, eu vehicula arcu finibus et. Etiam feugiat ultricies lobortis. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia curae; Praesent tortor nisl, fermentum vitae ante a, aliquet placerat eros. Morbi ultricies gravida felis in finibus. Donec urna arcu, luctus quis eros aliquam, accumsan aliquet magna. Etiam commodo condimentum pharetra. Duis vitae leo est. Praesent nec tincidunt nisi. Aenean ut imperdiet lectus, id placerat erat. Pellentesque sit amet scelerisque nunc. Sed malesuada, massa vitae posuere accumsan, enim sapien pellentesque odio, eu consectetur ipsum lacus id mauris.</p>

            <p>Ut in semper eros, lacinia pharetra turpis. Nam luctus nunc in leo efficitur vestibulum. Donec euismod arcu mauris, ut lobortis lacus dapibus a. Sed vitae dui vitae diam dignissim aliquam. Proin sed erat orci. Morbi euismod tellus a aliquam efficitur. Ut id sapien dapibus, consectetur tortor ut, aliquet felis. Nullam placerat magna ut purus fermentum interdum. Proin eu mauris a dolor lacinia ullamcorper. Quisque sodales diam et ligula facilisis, non semper quam ullamcorper. Phasellus egestas est in enim sagittis, id lobortis purus gravida. Interdum et malesuada fames ac ante ipsum primis in faucibus. Donec eget egestas arcu. Praesent ullamcorper rhoncus magna, non semper elit suscipit eget.</p>

            
                
    </div>
    

</div>

</body>
</html>
